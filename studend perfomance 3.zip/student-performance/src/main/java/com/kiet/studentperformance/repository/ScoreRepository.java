
package com.kiet.studentperformance.repository;

import com.kiet.studentperformance.entity.Score;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScoreRepository extends JpaRepository<Score, Integer> {
}
