
package com.kiet.studentperformance.controller;

import com.kiet.studentperformance.entity.*;
import com.kiet.studentperformance.repository.*;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentRepository studentRepository;
    private final ScoreRepository scoreRepository;
    private final TechnicalSkillRepository skillRepository;

    public StudentController(StudentRepository studentRepository,
                             ScoreRepository scoreRepository,
                             TechnicalSkillRepository skillRepository) {

        this.studentRepository = studentRepository;
        this.scoreRepository = scoreRepository;
        this.skillRepository = skillRepository;
    }

    // 1. Add Student
    @PostMapping
    public Student addStudent(@RequestBody Student student) {
        return studentRepository.save(student);
    }

    // 2. Get All Students
    @GetMapping
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // 3. Search Student By ID
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable int id) {

        return studentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 4. Update Student Scores and Skills
    @PutMapping("/{id}")
    public ResponseEntity<String> updateStudent(
            @PathVariable int id,
            @RequestBody Map<String, Object> data) {

        if (!studentRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Score score = new Score();
        score.setStudentId(id);
        score.setProgramming(new BigDecimal(data.get("programming").toString()));
        score.setMathematics(new BigDecimal(data.get("mathematics").toString()));
        score.setCommunication(new BigDecimal(data.get("communication").toString()));

        scoreRepository.save(score);

        skillRepository.deleteByStudentId(id);

        List<?> skills = (List<?>) data.get("skills");

        if (skills != null) {
            for (Object skillName : skills) {
                TechnicalSkill skill = new TechnicalSkill();
                skill.setStudentId(id);
                skill.setSkillName(skillName.toString());

                skillRepository.save(skill);
            }
        }

        return ResponseEntity.ok("Student scores and skills updated successfully");
    }

    // 5. Delete Student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable int id) {

        if (!studentRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        skillRepository.deleteByStudentId(id);
        scoreRepository.deleteById(id);
        studentRepository.deleteById(id);

        return ResponseEntity.ok("Student deleted successfully");
    }

    // 6. Display Merit List
    @GetMapping("/merit-list")
    public List<Map<String, Object>> getMeritList() {

        List<Map<String, Object>> meritList = new ArrayList<>();

        for (Student student : studentRepository.findAll()) {

            Optional<Score> optionalScore =
                    scoreRepository.findById(student.getStudentId());

            if (optionalScore.isEmpty()) {
                continue;
            }

            Score score = optionalScore.get();

            double programming = score.getProgramming().doubleValue();
            double mathematics = score.getMathematics().doubleValue();
            double communication = score.getCommunication().doubleValue();

            double average =
                    (programming + mathematics + communication) / 3.0;

            String category;

            if (average >= 85) {
                category = "Excellent";
            } else if (average >= 70) {
                category = "Good";
            } else if (average >= 50) {
                category = "Satisfactory";
            } else {
                category = "Needs Improvement";
            }

            String strongestSubject = "Programming";
            double highest = programming;

            if (mathematics > highest) {
                highest = mathematics;
                strongestSubject = "Mathematics";
            }

            if (communication > highest) {
                strongestSubject = "Communication";
            }

            Map<String, Object> result = new LinkedHashMap<>();

            result.put("studentId", student.getStudentId());
            result.put("studentName", student.getStudentName());
            result.put("average", Math.round(average * 100.0) / 100.0);
            result.put("category", category);
            result.put("strongestSubject", strongestSubject);

            meritList.add(result);
        }

        meritList.sort((a, b) ->
                Double.compare(
                        (Double) b.get("average"),
                        (Double) a.get("average")
                )
        );

        return meritList;
    }
}
