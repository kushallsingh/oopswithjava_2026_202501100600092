
package com.kiet.studentperformance.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "scores")
public class Score {

    @Id
    @Column(name = "student_id")
    private int studentId;

    private BigDecimal programming;

    private BigDecimal mathematics;

    private BigDecimal communication;

    public Score() {
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public BigDecimal getProgramming() {
        return programming;
    }

    public void setProgramming(BigDecimal programming) {
        this.programming = programming;
    }

    public BigDecimal getMathematics() {
        return mathematics;
    }

    public void setMathematics(BigDecimal mathematics) {
        this.mathematics = mathematics;
    }

    public BigDecimal getCommunication() {
        return communication;
    }

    public void setCommunication(BigDecimal communication) {
        this.communication = communication;
    }
}
