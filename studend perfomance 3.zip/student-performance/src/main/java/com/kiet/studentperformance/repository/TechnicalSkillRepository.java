
package com.kiet.studentperformance.repository;

import com.kiet.studentperformance.entity.TechnicalSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface TechnicalSkillRepository extends JpaRepository<TechnicalSkill, Integer> {

    List<TechnicalSkill> findByStudentId(int studentId);

    @Transactional
    void deleteByStudentId(int studentId);
}
