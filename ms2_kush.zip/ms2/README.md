# Student Management System

Spring Boot 3 REST API for registering students, calculating results, searching records, and reporting on skills. Uses Java 17, Maven, Spring Data JPA, MySQL, Jakarta Validation, and Swagger UI.

## Database and startup

Install and start MySQL. Create the database with `CREATE DATABASE student_management;` (or allow the configured JDBC URL to create it). The application creates/updates tables via Hibernate. Configure credentials without committing secrets:

```powershell
$env:DB_USERNAME='root'
$env:DB_PASSWORD='your-local-password'
```

Optional `DB_URL` defaults to `jdbc:mysql://localhost:3306/student_management?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC`. Blank password is the default placeholder; set your actual local credentials as needed. In IntelliJ, open this Maven project, select JDK 17, reload Maven, then run `StudentManagementApplication`. API: `http://localhost:8080`; Swagger: `http://localhost:8080/swagger-ui.html`.

For a quick Postman demo when MySQL credentials are not configured, run the IntelliJ configuration **Student Management Demo (H2)**. It uses a local file database under `data/`, seeds the ten demo students on an empty database, and serves the same API on port 8080. To choose it from the command line after building, run the application with `--spring.profiles.active=demo`. The default profile continues to use MySQL; configure `DB_USERNAME` and `DB_PASSWORD` for your MySQL account before running without the demo profile.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/students` | Register (201); duplicate ID/email returns 409 |
| GET | `/api/students` | List students |
| GET | `/api/students/{id}` | Retrieve student |
| PUT | `/api/students/{id}` | Replace student details, scores, and skills |
| DELETE | `/api/students/{id}` | Delete student and associated skill rows (204) |
| GET | `/api/students/merit-list` | Average descending; name and ID break ties |
| GET | `/api/students/search/email?email=...` | Case-insensitive exact email search |
| GET | `/api/students/search/course?course=...` | Case-insensitive course substring search |
| GET | `/api/students/performance` | Student performance report |
| GET | `/api/students/improvement` | Programming < 50 and Mathematics >= 75 |
| GET | `/api/students/shared-skills` | Skills shared by at least two students |
| GET | `/api/students/shared-skills?skill=Java` | Students sharing a named skill |
| GET | `/api/students/{id}/analysis` | Analysis included with student data |

### Example

```json
{
  "id": 1001,
  "name": "Aarav Mehta",
  "email": "aarav@example.edu",
  "course": "Computer Science",
  "programmingScore": 91,
  "mathematicsScore": 84,
  "technicalSkills": ["Java", "SQL"]
}
```

```powershell
curl.exe -X POST http://localhost:8080/api/students -H "Content-Type: application/json" -d '{"id":1001,"name":"Aarav Mehta","email":"aarav@example.edu","course":"Computer Science","programmingScore":91,"mathematicsScore":84,"technicalSkills":["Java","SQL"]}'
curl.exe "http://localhost:8080/api/students/merit-list"
curl.exe "http://localhost:8080/api/students/shared-skills?skill=Java"
```

Responses include `average`, `performanceCategory`, and `strongerSubject`. Categories use thresholds 85, 70, and 50; equal scores yield `Equal`. Invalid requests return 400, missing IDs return 404, duplicates return 409.

## Sample data

Ten realistic demo records are included in `DemoDataLoader`. To load them once into an empty database, set `app.seed-demo-data=true` in `application.properties` or as an environment-backed Spring property (`SPRING_APPLICATION_JSON='{"app":{"seed-demo-data":true}}'`). It does nothing unless enabled and the table is empty, so restarts cannot duplicate records. Remove the option after seeding if you prefer.

## Database structure

`students` stores the ID primary key, unique email, name, course, and integer scores. `student_skills` stores one skill per row and a student foreign key; JPA element collection removes those rows with the owning student.
