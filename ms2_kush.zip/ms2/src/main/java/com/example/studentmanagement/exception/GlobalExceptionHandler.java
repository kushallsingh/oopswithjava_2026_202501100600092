package com.example.studentmanagement.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {
 @ExceptionHandler(StudentNotFoundException.class) ResponseEntity<Map<String,String>> notFound(RuntimeException e){return response(HttpStatus.NOT_FOUND,e.getMessage());}
 @ExceptionHandler(DuplicateStudentException.class) ResponseEntity<Map<String,String>> conflict(RuntimeException e){return response(HttpStatus.CONFLICT,e.getMessage());}
 @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<Map<String,String>> badRequest(IllegalArgumentException e){return response(HttpStatus.BAD_REQUEST,e.getMessage());}
 @ExceptionHandler({DataIntegrityViolationException.class}) ResponseEntity<Map<String,String>> conflict(Exception e){return response(HttpStatus.CONFLICT,"Student ID or email already exists");}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<Map<String,String>> invalid(MethodArgumentNotValidException e){Map<String,String> errors=new LinkedHashMap<>(); e.getBindingResult().getFieldErrors().forEach(x->errors.putIfAbsent(x.getField(),x.getDefaultMessage())); return ResponseEntity.badRequest().body(Map.of("error","Validation failed","details",errors.toString()));}
 private ResponseEntity<Map<String,String>> response(HttpStatus status,String message){return ResponseEntity.status(status).body(Map.of("error",message));}
}
