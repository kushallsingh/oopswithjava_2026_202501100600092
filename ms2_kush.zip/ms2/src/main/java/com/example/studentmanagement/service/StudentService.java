package com.example.studentmanagement.service;

import com.example.studentmanagement.dto.*;
import com.example.studentmanagement.entity.Student;
import com.example.studentmanagement.exception.*;
import com.example.studentmanagement.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StudentService {
 private final StudentRepository repository;
 public StudentService(StudentRepository repository){this.repository=repository;}
 @Transactional public StudentResponse create(StudentRequest r){if(repository.existsById(r.id())) throw new DuplicateStudentException("Student ID " + r.id() + " already exists"); if(repository.findByEmailIgnoreCase(r.email()).isPresent()) throw new DuplicateStudentException("Email already exists"); return StudentResponse.from(repository.save(toStudent(r)));}
 public List<StudentResponse> all(){return repository.findAll().stream().map(StudentResponse::from).toList();}
 public StudentResponse get(Long id){return StudentResponse.from(find(id));}
 @Transactional public StudentResponse update(Long id,StudentRequest r){Student s=find(id); if(!id.equals(r.id())) throw new IllegalArgumentException("Request ID must match URL ID"); repository.findByEmailIgnoreCase(r.email()).filter(other->!other.getId().equals(id)).ifPresent(other->{throw new DuplicateStudentException("Email already exists");}); s.setName(r.name());s.setEmail(r.email());s.setCourse(r.course());s.setProgrammingScore(r.programmingScore());s.setMathematicsScore(r.mathematicsScore());s.setTechnicalSkills(r.technicalSkills());return StudentResponse.from(s);}
 public void delete(Long id){repository.delete(find(id));}
 public List<StudentResponse> merit(){return repository.findAll().stream().sorted(Comparator.comparingDouble(Student::calculateAverage).reversed().thenComparing(Student::getName,String.CASE_INSENSITIVE_ORDER).thenComparing(Student::getId)).map(StudentResponse::from).toList();}
 public List<StudentResponse> email(String email){return repository.findByEmailIgnoreCase(email).map(s->List.of(StudentResponse.from(s))).orElse(List.of());}
 public List<StudentResponse> course(String course){return repository.findByCourseContainingIgnoreCase(course).stream().map(StudentResponse::from).toList();}
 public List<StudentResponse> improvement(){return repository.findByProgrammingScoreLessThanAndMathematicsScoreGreaterThanEqual(50,75).stream().map(StudentResponse::from).toList();}
 public Map<String,List<StudentResponse>> sharedSkills(){Map<String,List<StudentResponse>> result=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);for(Student s:repository.findAll()) for(String skill:s.getTechnicalSkills())result.computeIfAbsent(skill,k->new ArrayList<>()).add(StudentResponse.from(s));result.entrySet().removeIf(e->e.getValue().size()<2);return result;}
 public List<StudentResponse> bySkill(String skill){return repository.findAll().stream().filter(s->s.getTechnicalSkills().stream().anyMatch(x->x.equalsIgnoreCase(skill))).map(StudentResponse::from).toList();}
 public Map<String,Object> performance(){Map<String,Object> out=new LinkedHashMap<>();for(StudentResponse s:all())out.put(String.valueOf(s.id()),Map.of("name",s.name(),"average",s.average(),"category",s.performanceCategory()));return out;}
 private Student find(Long id){return repository.findById(id).orElseThrow(()->new StudentNotFoundException(id));}
 private Student toStudent(StudentRequest r){return new Student(r.id(),r.name().trim(),r.email().trim(),r.course().trim(),r.programmingScore(),r.mathematicsScore(),r.technicalSkills());}
}
