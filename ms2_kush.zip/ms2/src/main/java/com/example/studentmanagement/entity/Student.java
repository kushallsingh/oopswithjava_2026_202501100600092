package com.example.studentmanagement.entity;

import jakarta.persistence.*;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "students")
public class Student {
    @Id private Long id;
    @Column(nullable = false, length = 100) private String name;
    @Column(nullable = false, unique = true, length = 160) private String email;
    @Column(nullable = false, length = 100) private String course;
    @Column(nullable = false) private int programmingScore;
    @Column(nullable = false) private int mathematicsScore;
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "student_skills", joinColumns = @JoinColumn(name = "student_id"))
    @Column(name = "skill", nullable = false, length = 80)
    private Set<String> technicalSkills = new LinkedHashSet<>();

    protected Student() { }
    public Student(Long id, String name, String email, String course, int programmingScore, int mathematicsScore, Set<String> skills) {
        this.id=id; this.name=name; this.email=email; this.course=course; this.programmingScore=programmingScore; this.mathematicsScore=mathematicsScore; this.technicalSkills=new LinkedHashSet<>(skills);
    }
    public Long getId(){return id;} public String getName(){return name;} public String getEmail(){return email;} public String getCourse(){return course;}
    public int getProgrammingScore(){return programmingScore;} public int getMathematicsScore(){return mathematicsScore;} public Set<String> getTechnicalSkills(){return technicalSkills;}
    public void setName(String v){name=v;} public void setEmail(String v){email=v;} public void setCourse(String v){course=v;}
    public void setProgrammingScore(int v){programmingScore=v;} public void setMathematicsScore(int v){mathematicsScore=v;}
    public void setTechnicalSkills(Set<String> v){technicalSkills=new LinkedHashSet<>(v);}
    public double calculateAverage(){return (programmingScore+mathematicsScore)/2.0;}
    public String getPerformanceCategory(){double a=calculateAverage(); return a>=85?"Excellent":a>=70?"Good":a>=50?"Satisfactory":"Needs Improvement";}
    public String getStrongerSubject(){return programmingScore>mathematicsScore?"Programming":mathematicsScore>programmingScore?"Mathematics":"Equal";}
    @Override public String toString(){return "Student{id="+id+", name='"+name+"', average="+calculateAverage()+"}";}
}
