package com.example.studentmanagement.controller;

import com.example.studentmanagement.dto.*;
import com.example.studentmanagement.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/students")
public class StudentController {
 private final StudentService service;
 public StudentController(StudentService service){this.service=service;}
 @PostMapping public ResponseEntity<StudentResponse> create(@Valid @RequestBody StudentRequest request){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));}
 @GetMapping public List<StudentResponse> all(){return service.all();}
 @GetMapping("/{id}") public StudentResponse get(@PathVariable Long id){return service.get(id);}
 @PutMapping("/{id}") public StudentResponse update(@PathVariable Long id,@Valid @RequestBody StudentRequest request){return service.update(id,request);}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){service.delete(id);return ResponseEntity.noContent().build();}
 @GetMapping("/merit-list") public List<StudentResponse> merit(){return service.merit();}
 @GetMapping("/search/email") public List<StudentResponse> email(@RequestParam String email){return service.email(email);}
 @GetMapping("/search/course") public List<StudentResponse> course(@RequestParam String course){return service.course(course);}
 @GetMapping("/performance") public Map<String,Object> performance(){return service.performance();}
 @GetMapping("/improvement") public List<StudentResponse> improvement(){return service.improvement();}
 @GetMapping("/shared-skills") public Map<String,List<StudentResponse>> sharedSkills(@RequestParam(required=false) String skill){return skill==null?service.sharedSkills():Map.of(skill,service.bySkill(skill));}
 @GetMapping("/{id}/analysis") public StudentResponse analysis(@PathVariable Long id){return service.get(id);}
}
