package com.example.studentmanagement.exception;
public class DuplicateStudentException extends RuntimeException { public DuplicateStudentException(String message){super(message);} }
