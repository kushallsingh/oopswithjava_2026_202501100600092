package com.example.studentmanagement.repository;

import com.example.studentmanagement.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
 Optional<Student> findByEmailIgnoreCase(String email);
 List<Student> findByCourseContainingIgnoreCase(String course);
 List<Student> findByProgrammingScoreLessThanAndMathematicsScoreGreaterThanEqual(int programming, int mathematics);
}
