package com.example.studentmanagement.dto;

import com.example.studentmanagement.entity.Student;
import java.util.Set;

public record StudentResponse(Long id, String name, String email, String course, int programmingScore,
 int mathematicsScore, Set<String> technicalSkills, double average, String performanceCategory, String strongerSubject) {
 public static StudentResponse from(Student s){return new StudentResponse(s.getId(),s.getName(),s.getEmail(),s.getCourse(),s.getProgrammingScore(),s.getMathematicsScore(),Set.copyOf(s.getTechnicalSkills()),s.calculateAverage(),s.getPerformanceCategory(),s.getStrongerSubject());}
}
