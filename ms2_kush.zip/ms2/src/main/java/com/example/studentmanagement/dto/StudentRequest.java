package com.example.studentmanagement.dto;

import jakarta.validation.constraints.*;
import java.util.Set;

public record StudentRequest(@NotNull @Positive Long id, @NotBlank @Size(max=100) String name,
 @NotBlank @Email @Size(max=160) String email, @NotBlank @Size(max=100) String course,
 @Min(0) @Max(100) int programmingScore, @Min(0) @Max(100) int mathematicsScore,
 @NotNull Set<@NotBlank @Size(max=80) String> technicalSkills) { }
