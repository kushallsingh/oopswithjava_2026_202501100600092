package com.example.studentmanagement.config;

import com.example.studentmanagement.entity.Student;
import com.example.studentmanagement.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.Set;

@Configuration
public class DemoDataLoader {
 @Bean CommandLineRunner loadDemoData(StudentRepository repository, @Value("${app.seed-demo-data:false}") boolean enabled){
  return args->{if(!enabled||repository.count()>0)return;
   repository.saveAll(java.util.List.of(
    new Student(1001L,"Aarav Mehta","aarav@example.edu","Computer Science",91,84,Set.of("Java","SQL","Git")),
    new Student(1002L,"Diya Sharma","diya@example.edu","Information Technology",88,92,Set.of("Python","SQL","Git")),
    new Student(1003L,"Kabir Patel","kabir@example.edu","Computer Science",76,73,Set.of("Java","Python")),
    new Student(1004L,"Ananya Rao","ananya@example.edu","Data Science",95,89,Set.of("Python","SQL","Machine Learning")),
    new Student(1005L,"Ishaan Gupta","ishaan@example.edu","Information Technology",64,58,Set.of("Java","HTML","CSS")),
    new Student(1006L,"Meera Nair","meera@example.edu","Data Science",42,81,Set.of("Python","Machine Learning","SQL")),
    new Student(1007L,"Rohan Singh","rohan@example.edu","Computer Science",48,78,Set.of("Java","Git","HTML")),
    new Student(1008L,"Sara Khan","sara@example.edu","Cyber Security",82,86,Set.of("Linux","Python","Git")),
    new Student(1009L,"Vivaan Das","vivaan@example.edu","Cyber Security",55,49,Set.of("Linux","Java")),
    new Student(1010L,"Aditi Joshi","aditi@example.edu","Information Technology",70,70,Set.of("Java","SQL","CSS"))));
  };
 }
}
