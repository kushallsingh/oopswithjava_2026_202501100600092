CREATE DATABASE IF NOT EXISTS student_management;
-- Hibernate creates and maintains the students and student_skills tables on startup.
