package com.example.studentmanagement.entity;

import org.junit.jupiter.api.Test;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class StudentTest {
 @Test void calculatesAverageCategoryAndStrongerSubject(){Student s=new Student(1L,"Test","t@example.com","CS",90,80,Set.of("Java"));assertEquals(85.0,s.calculateAverage());assertEquals("Excellent",s.getPerformanceCategory());assertEquals("Programming",s.getStrongerSubject());}
 @Test void equalScoresAreReported(){Student s=new Student(2L,"Test","t@example.com","CS",50,50,Set.of());assertEquals("Equal",s.getStrongerSubject());assertEquals("Satisfactory",s.getPerformanceCategory());}
}
