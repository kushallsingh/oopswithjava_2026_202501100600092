
import java.sql.*;
import java.util.Scanner;

public class StudentPerformanceApp {

    static final String SERVER_URL =
            "jdbc:mysql://localhost:3306/";

    static final String DB_URL =
            "jdbc:mysql://localhost:3306/student_performance";

    static final String USER = "root";
    static final String PASSWORD = "root";

    static Scanner sc = new Scanner(System.in);
    static Connection con;

    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // STEP 1: Create database and tables
            createDatabaseAndTables();

            // STEP 2: Connect to database
            con = DriverManager.getConnection(
                    DB_URL, USER, PASSWORD
            );

            System.out.println("\nDatabase Connected Successfully!");

            // STEP 3: Insert sample records if they don't exist
            insertSampleData();

            // STEP 4: Display menu
            while (true) {

                System.out.println("\n--- STUDENT PERFORMANCE SYSTEM ---");
                System.out.println("1. Add Student");
                System.out.println("2. Calculate Average and Category");
                System.out.println("3. Find Strongest Subject");
                System.out.println("4. Search Student");
                System.out.println("5. Display Merit List");
                System.out.println("6. Find Common Technical Skills");
                System.out.println("7. Students Needing Programming Improvement");
                System.out.println("8. Exit");

                System.out.print("Enter choice: ");
                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        addStudent();
                        break;

                    case 2:
                        displayAverage();
                        break;

                    case 3:
                        strongestSubject();
                        break;

                    case 4:
                        searchStudent();
                        break;

                    case 5:
                        meritList();
                        break;

                    case 6:
                        commonSkills();
                        break;

                    case 7:
                        improvementStudents();
                        break;

                    case 8:
                        con.close();
                        System.out.println("Program Closed.");
                        return;

                    default:
                        System.out.println("Invalid Choice!");
                }
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // STEP 1: CREATE DATABASE AND TABLES
    static void createDatabaseAndTables() throws SQLException {

        Connection temp = DriverManager.getConnection(
                SERVER_URL, USER, PASSWORD
        );

        Statement st = temp.createStatement();

        // Create database
        st.executeUpdate(
                "CREATE DATABASE IF NOT EXISTS student_performance"
        );

        System.out.println("Database Created/Already Exists.");

        // Select database
        st.executeUpdate("USE student_performance");

        // Create Students table
        String sql = """
                CREATE TABLE IF NOT EXISTS students (
                    student_id INT PRIMARY KEY,
                    student_name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    course VARCHAR(50) NOT NULL
                )
                """;

        st.executeUpdate(sql);

        // Create Scores table
        sql = """
                CREATE TABLE IF NOT EXISTS scores (
                    student_id INT PRIMARY KEY,
                    programming DECIMAL(5,2) NOT NULL,
                    mathematics DECIMAL(5,2) NOT NULL,
                    communication DECIMAL(5,2) NOT NULL,

                    FOREIGN KEY (student_id)
                    REFERENCES students(student_id)
                    ON DELETE CASCADE,

                    CHECK (programming BETWEEN 0 AND 100),
                    CHECK (mathematics BETWEEN 0 AND 100),
                    CHECK (communication BETWEEN 0 AND 100)
                )
                """;

        st.executeUpdate(sql);

        // Create Technical Skills table
        sql = """
                CREATE TABLE IF NOT EXISTS technical_skills (
                    skill_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    skill_name VARCHAR(50) NOT NULL,

                    FOREIGN KEY (student_id)
                    REFERENCES students(student_id)
                    ON DELETE CASCADE,

                    UNIQUE(student_id, skill_name)
                )
                """;

        st.executeUpdate(sql);

        System.out.println("All Tables Created/Already Exist.");

        st.close();
        temp.close();
    }

    // STEP 2: INSERT SAMPLE DATA IF NOT EXISTS
    static void insertSampleData() {

        try {

            // Insert students
            String sql = """
                    INSERT IGNORE INTO students
                    (student_id, student_name, email, course)
                    VALUES
                    (101, 'Rahul', 'rahul@gmail.com', 'CSE'),
                    (102, 'Aman', 'aman@gmail.com', 'CSE'),
                    (103, 'Priya', 'priya@gmail.com', 'IT'),
                    (104, 'Neha', 'neha@gmail.com', 'AI'),
                    (105, 'Karan', 'karan@gmail.com', 'IT')
                    """;

            Statement st = con.createStatement();
            st.executeUpdate(sql);

            // Insert scores
            sql = """
                    INSERT IGNORE INTO scores
                    (student_id, programming, mathematics, communication)
                    VALUES
                    (101, 90, 85, 80),
                    (102, 65, 80, 70),
                    (103, 45, 85, 60),
                    (104, 75, 65, 80),
                    (105, 40, 78, 55)
                    """;

            st.executeUpdate(sql);

            // Insert technical skills
            sql = """
                    INSERT IGNORE INTO technical_skills
                    (student_id, skill_name)
                    VALUES
                    (101, 'Java'),
                    (101, 'Python'),
                    (102, 'Java'),
                    (102, 'Python'),
                    (103, 'C++'),
                    (104, 'Python'),
                    (104, 'Java'),
                    (105, 'C++')
                    """;

            st.executeUpdate(sql);

            st.close();

            System.out.println("Sample Data Inserted/Already Exists.");

        } catch (SQLException e) {
            System.out.println("Sample Data Error: " + e.getMessage());
        }
    }

    // 1. ADD STUDENT
    static void addStudent() {

        try {

            System.out.print("Student ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("Email: ");
            String email = sc.nextLine();

            System.out.print("Course: ");
            String course = sc.nextLine();

            System.out.print("Programming Marks: ");
            double p = sc.nextDouble();

            System.out.print("Mathematics Marks: ");
            double m = sc.nextDouble();

            System.out.print("Communication Marks: ");
            double c = sc.nextDouble();

            if (p < 0 || p > 100 ||
                    m < 0 || m > 100 ||
                    c < 0 || c > 100) {

                System.out.println(
                        "Scores must be between 0 and 100."
                );

                sc.nextLine();
                return;
            }

            System.out.print("Number of technical skills: ");
            int n = sc.nextInt();
            sc.nextLine();

            if (n < 0) {
                System.out.println("Invalid number of skills.");
                return;
            }

            con.setAutoCommit(false);

            try {

                // Insert student
                String sql = """
                        INSERT INTO students
                        (student_id, student_name, email, course)
                        VALUES (?, ?, ?, ?)
                        """;

                PreparedStatement ps = con.prepareStatement(sql);

                ps.setInt(1, id);
                ps.setString(2, name);
                ps.setString(3, email);
                ps.setString(4, course);

                ps.executeUpdate();
                ps.close();

                // Insert scores
                sql = """
                        INSERT INTO scores
                        (student_id, programming, mathematics, communication)
                        VALUES (?, ?, ?, ?)
                        """;

                ps = con.prepareStatement(sql);

                ps.setInt(1, id);
                ps.setDouble(2, p);
                ps.setDouble(3, m);
                ps.setDouble(4, c);

                ps.executeUpdate();
                ps.close();

                // Insert technical skills
                sql = """
                        INSERT INTO technical_skills
                        (student_id, skill_name)
                        VALUES (?, ?)
                        """;

                ps = con.prepareStatement(sql);

                for (int i = 0; i < n; i++) {

                    System.out.print("Enter skill: ");
                    String skill = sc.nextLine();

                    ps.setInt(1, id);
                    ps.setString(2, skill);

                    ps.executeUpdate();
                }

                ps.close();

                con.commit();

                System.out.println("Student Added Successfully!");

            } catch (SQLException e) {

                con.rollback();

                System.out.println(
                        "Insertion Failed: " + e.getMessage()
                );

            } finally {
                con.setAutoCommit(true);
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // 2. CALCULATE AVERAGE AND CATEGORY
    static void displayAverage() {

        String sql = """
                SELECT s.student_id, s.student_name,

                ROUND(
                    (sc.programming + sc.mathematics +
                    sc.communication) / 3, 2
                ) AS avg_score,

                CASE
                    WHEN (sc.programming + sc.mathematics +
                          sc.communication) / 3 >= 85
                        THEN 'Excellent'

                    WHEN (sc.programming + sc.mathematics +
                          sc.communication) / 3 >= 70
                        THEN 'Good'

                    WHEN (sc.programming + sc.mathematics +
                          sc.communication) / 3 >= 50
                        THEN 'Satisfactory'

                    ELSE 'Needs Improvement'
                END AS category

                FROM students s
                JOIN scores sc
                ON s.student_id = sc.student_id
                """;

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(
                        rs.getInt("student_id") + " | " +
                                rs.getString("student_name") + " | " +
                                rs.getDouble("avg_score") + " | " +
                                rs.getString("category")
                );
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // 3. FIND STRONGEST SUBJECT
    static void strongestSubject() {

        String sql = """
                SELECT s.student_id, s.student_name,

                CASE
                    WHEN sc.programming >= sc.mathematics
                         AND sc.programming >= sc.communication
                        THEN 'Programming'

                    WHEN sc.mathematics >= sc.communication
                        THEN 'Mathematics'

                    ELSE 'Communication'
                END AS strongest

                FROM students s
                JOIN scores sc
                ON s.student_id = sc.student_id
                """;

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(
                        rs.getInt("student_id") + " | " +
                                rs.getString("student_name") + " | " +
                                rs.getString("strongest")
                );
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // 4. SEARCH BY ID, EMAIL OR COURSE
    static void searchStudent() {

        System.out.println("\n1. Search by ID");
        System.out.println("2. Search by Email");
        System.out.println("3. Search by Course");

        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        sc.nextLine();

        String sql;

        switch (choice) {

            case 1:
                sql = "SELECT * FROM students WHERE student_id = ?";
                break;

            case 2:
                sql = "SELECT * FROM students WHERE email = ?";
                break;

            case 3:
                sql = "SELECT * FROM students WHERE course = ?";
                break;

            default:
                System.out.println("Invalid Choice!");
                return;
        }

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            System.out.print("Enter search value: ");

            if (choice == 1) {
                int id = sc.nextInt();
                sc.nextLine();
                ps.setInt(1, id);
            } else {
                String value = sc.nextLine();
                ps.setString(1, value);
            }

            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        rs.getInt("student_id") + " | " +
                                rs.getString("student_name") + " | " +
                                rs.getString("email") + " | " +
                                rs.getString("course")
                );
            }

            if (!found) {
                System.out.println("Student Not Found!");
            }

            rs.close();
            ps.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // 5. GENERATE MERIT LIST
    static void meritList() {

        String sql = """
                SELECT s.student_id, s.student_name,

                ROUND(
                    (sc.programming + sc.mathematics +
                    sc.communication) / 3, 2
                ) AS avg_score

                FROM students s
                JOIN scores sc
                ON s.student_id = sc.student_id

                ORDER BY avg_score DESC
                """;

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            int rank = 1;

            System.out.println("\n--- MERIT LIST ---");

            while (rs.next()) {

                System.out.println(
                        rank++ + ". " +
                                rs.getInt("student_id") + " | " +
                                rs.getString("student_name") + " | " +
                                rs.getDouble("avg_score")
                );
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // 6. FIND COMMON TECHNICAL SKILLS
    static void commonSkills() {

        String sql = """
                SELECT
                    s1.student_name AS student1,
                    s2.student_name AS student2,
                    t1.skill_name

                FROM technical_skills t1

                JOIN technical_skills t2
                ON t1.skill_name = t2.skill_name
                AND t1.student_id < t2.student_id

                JOIN students s1
                ON t1.student_id = s1.student_id

                JOIN students s2
                ON t2.student_id = s2.student_id

                ORDER BY t1.skill_name
                """;

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n--- COMMON TECHNICAL SKILLS ---");

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        rs.getString("student1") +
                                " and " +
                                rs.getString("student2") +
                                " share " +
                                rs.getString("skill_name")
                );
            }

            if (!found) {
                System.out.println("No common skills found.");
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // 7. STUDENTS NEEDING PROGRAMMING IMPROVEMENT
    static void improvementStudents() {

        String sql = """
                SELECT
                    s.student_id,
                    s.student_name,
                    sc.programming,
                    sc.mathematics

                FROM students s

                JOIN scores sc
                ON s.student_id = sc.student_id

                WHERE sc.programming < 50
                AND sc.mathematics >= 75
                """;

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println(
                    "\n--- STUDENTS NEEDING PROGRAMMING IMPROVEMENT ---"
            );

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        rs.getInt("student_id") + " | " +
                                rs.getString("student_name") +
                                " | Programming: " +
                                rs.getDouble("programming") +
                                " | Mathematics: " +
                                rs.getDouble("mathematics")
                );
            }

            if (!found) {
                System.out.println("No students found.");
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
